// Setup FaunaDB
var faunadb = require("faunadb"),
  q = faunadb.query;

// ******************************* FAUNADB *********************************

/** Function to add a single item to FaunaDB
 * @param param_Object: is an object that has the name of the collection and data object
 * @returns { ref, data{}, ts }
 */
module.exports.addSingleItem = async function(param_Object) {
  const { collection, data } = param_Object; 
  try {
    const response = await client.query(q.Create(q.Collection(collection), {data}));
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function to add mutiple items to FaunaDB
 * @param param_Object: is an object that has the name of the collection and data array of objects
 * @returns { ref, data{}, ts }
 */
module.exports.addMultipleItem = async function(param_Object) {
  const { collection, dataArrayObject } = param_Object;
  try {
    const response = await client.query(q.Map(dataArrayObject, q.Lambda('value',
                        q.Create(q.Collection(collection), { data: q.Var('value')}))));
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function to add item to FaunaDB
 * @param param_Object: is an object that has the name of the collection and data array of objects
 * @returns { ref, data{}, ts }
 */
module.exports.getItem = async function(param_Object) {
  const { collection, ref } = param_Object;
  try {
    const response = await client.query(q.Get(q.Ref(q.Collection(collection), ref)));
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function to add item to FaunaDB
 * @param 
 * @returns { ref, data{}, ts }
 */
module.exports.getItemByIndex = async function(param_Object) {
  const { index, title } = param_Object;
  try {
    const response = await client.query(q.Get(q.Match(q.Index(index), title)));
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function to add item to FaunaDB
 * @param param_Object: is an object that has the name of the collection and data array of objects
 * @returns { ref, data{}, ts }
 */
module.exports.getItems = async function(param_Object) {
  const { collection, ref } = param_Object;
  try {
    const response = await client.query(q.Get(q.Ref(q.Collection(collection), ref)));
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function to add item to FaunaDB
 * @param 
 * @returns { ref, data{}, ts }
 */
module.exports.updateItem = async function(param_Object) {
  const { collection, ref, data} = param_Object;
  try {
    const response = await client.query(q.Update(q.Ref(q.Collection(collection), ref),{data: {data}}));
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function to add item to FaunaDB
 * @param 
 * @returns { ref, data{}, ts }
 */
module.exports.deleteItem = async function(param_Object) {
  const { collection, ref} = param_Object;
  try {
    const response = await client.query(q.Delete(q.Ref(q.Collection(collection), ref)))
    return JSON.stringify(response, null, 2);
  } catch (error) {
    return JSON.stringify(error, null, 2);
  }
};

/** Function that creates a database with a secret
 * @param credentials: contains the data field gotten from the Authorize Header
 * @returns { ref: Ref(id=db-next, collection=Ref(id=databases)),ts: 1527274824500534, name: databasename}
*/
module.exports.createDatabase = async function(param_object) {
  const { secret, name } = param_object;
  // the secret is passed in from the param_object created with some data from request header
  var client = new faunadb.Client({ secret: secret });
  const response = client.query(q.CreateDatabase({ 
      name: name, 
  }))
  return response;
}

/** Function that creates a collection (table)
 * @param credentials: contains the data field gotten from the Authorize Header
 * @returns { ref, name, ts, history_days}
*/
module.exports.createCollection = async function(param_object) {
  const { secret, name } = param_object;
  // the secret is passed in from the param_object created with some data from request header
  var client = new faunadb.Client({ secret: secret });
  const response = client.query(q.CreateCollection({name: name}));
  return response;
}

/** Function that creates an index for a collection (table)
 * @param credentials: contains the data field gotten from the Authorize Header
 * @returns { ref: Ref(id=db-next, collection=Ref(id=databases)),ts: 1527274824500534, name: databasename}
*/
module.exports.createIndex = async function(param_Object) {
    const { name, collection } = param_Object;
    const response = client.query(q.CreateIndex({
      name: name,
      source: q.collectio(collection)
    }))
    return response;
}

/** Function that creates an index for a collection (table)
 * @param credentials: contains the data field gotten from the Authorize Header
 * @returns { ref: Ref(id=db-next, collection=Ref(id=databases)),ts: 1527274824500534, name: databasename}
*/
module.exports.createIndexWithTermAndValue = async function(param_Object) {
  const { name, collection } = param_Object;
  const response = client.query(q.CreateIndex({
    name: name,
    source: q.Collection(collection),
    terms: [{ field: ['data', 'tags'] }],
    values: [{ field: ['data', 'title'] }],
  }))
  return response;
}

/** @param param_Object: contains the data field gotten from the Authorize Header
 * @returns { ref: Ref(id=db-next, collection=Ref(id=databases)),ts: 1527274824500534, name: databasename}
*/
module.exports.getDataByID = async function(param_Object) {
    var result = [];
    dataArray.map(id => {
        try {
            const response = await this.getItem(id, credentials);
            const data = response.data;
            result.push(data);
        }catch(error){
            return result.push(error);
        }
    });
}